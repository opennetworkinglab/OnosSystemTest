'''
	
 *   TestON is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 2 of the License, or
 *   (at your option) any later version.

 *   TestON is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.


'''
class MininetTest :

    def __init__(self) :
        self.default = ''

    def CASE1(self,main) :

        main.case("Testing the configuration of the host")
        main.step("Host IP Checking using checkIP")
        result = main.Mininet1.checkIP(main.params['CASE1']['destination'])
        main.step("Verifying the result")
        utilities.assert_equals(expect=main.TRUE,actual=result,onpass="Host h2 IP address configured",onfail="Host h2 IP address didn't configured")
    
    def CASE2(self,main) :

        main.case("Testing Reachabilty of all the hosts")
        main.step("Checking Hosts reachability by using pingall")
        result = main.Mininet1.pingall()
        main.step("Verifying the result")
        utilities.assert_equals(expect=main.TRUE,actual=result,onpass="All hosts are reacchable",onfail="Hosts are not reachable")
